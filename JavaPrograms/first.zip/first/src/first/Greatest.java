package first;
import java.io.*;

import java.util.Scanner;
public class Greatest 
{
	    static int a=2;
		static int b=4;
		public static void main(String[] args) 
		{
			
			System.out.println("a="+a);
			System.out.println("b="+b);
			
		if(a>b)
		{
			   System.out.println("a is large");
		}	   
		else
		{	
				System.out.println("b is large");	
		}
		}
		
}


