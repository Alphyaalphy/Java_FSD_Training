package first;

import java.util.Scanner;
import java.io.*;
class ArithmeticOperation 
{
	public static void main(String[] args) {
		 
		int sum, sub, mul,p,q ;
        float div;
        Scanner scanner=new Scanner(System.in);
		System.out.println("Enter any two positive integer numbers:");

        
        p = scanner.nextInt();
        q = scanner.nextInt();
        

        sum = p + q;
        System.out.println("sum         " + p + " + " + q + " = " + sum);
        sub = p - q;
        System.out.println("differance  " + p + " - " + q + " = " + sub);
        mul = p * q;
        System.out.println("product     " + p + " * " + q + " = " + mul);
        div = p / q;
        System.out.println("div     " + p + " / " + q + " = " + div);

	}

}
