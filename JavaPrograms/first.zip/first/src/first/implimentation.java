package first;

public class implimentation {
int myVariable;
static int data = 60;

public static void main(String[] args) {

int a = 200;
implimentation obj = new implimentation();
     
     System.out.println("Value of instance variable myVariable: "+obj.myVariable);
     System.out.println("Value of static variable data: "+implimentation.data);
     System.out.println("Value of local variable a: "+a);

}

}

